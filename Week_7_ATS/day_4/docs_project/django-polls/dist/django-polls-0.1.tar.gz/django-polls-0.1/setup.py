import setuptools

import setup

setuptools.setup()